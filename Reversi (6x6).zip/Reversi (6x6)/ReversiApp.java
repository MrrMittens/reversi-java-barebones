public class ReversiApp {
    public static void main(String[] args) {
        ReversiGUI gui = new ReversiGUI();
        gui.setUpGUI();
        gui.setUpButtonListener();
    }
}